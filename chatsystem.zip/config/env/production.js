module.exports = {
    // Production configuration options
    db: "mongodb://localhost:27017/chat",
    sessionSecret: "09090910"
};