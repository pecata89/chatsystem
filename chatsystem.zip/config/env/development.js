module.exports = {
    // Development configuration options
    db: "mongodb://localhost:27017/chat",
    sessionSecret: "080808"
};